package com.example.formulario

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nombre = findViewById<EditText>(R.id.etNombre)
        val apellidoPaterno = findViewById<EditText>(R.id.etApellidoPaterno)
        val apellidoMaterno = findViewById<EditText>(R.id.etApellidoMaterno)
        val edad = findViewById<EditText>(R.id.etEdad)
        val calle = findViewById<EditText>(R.id.etCalle)
        val celular = findViewById<EditText>(R.id.etCelular)
        val carrera = findViewById<EditText>(R.id.etCarrera)
        val numeroControl = findViewById<EditText>(R.id.etNumeroControl)
        val botonLimpiar = findViewById<Button>(R.id.btnLimpiar)

       // Acción para limpiar los campos
        botonLimpiar.setOnClickListener {
            nombre.text.clear()
            apellidoPaterno.text.clear()
            apellidoMaterno.text.clear()
            edad.text.clear()
            calle.text.clear()
            celular.text.clear()
            carrera.text.clear()
            numeroControl.text.clear()
            Toast.makeText(this, "Formulario limpiado", Toast.LENGTH_SHORT).show()
        }
    }
}

