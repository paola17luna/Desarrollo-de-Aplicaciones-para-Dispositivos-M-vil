package com.example.numerorandom

import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var matrizBotones: GridLayout
    private lateinit var btnOk: Button
    private lateinit var btnLimpiar: Button
    private val botones = mutableListOf<Button>()  // Guarda los 25 botones

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        matrizBotones = findViewById(R.id.matrizBotones)
        btnOk = findViewById(R.id.btnOk)
        btnLimpiar = findViewById(R.id.btnLimpiar)

        // Crear y agregar los 25 botones al GridLayout
        crearMatriz()

        // Asigna números aleatorios al iniciar
        asignarNumerosRandom()

        // Botón OK: genera nuevos números aleatorios
        btnOk.setOnClickListener {
            asignarNumerosRandom()
        }

        // Botón Limpiar: borra los números de los botones
        btnLimpiar.setOnClickListener {
            limpiarMatriz()
        }
    }

    private fun crearMatriz() {
        for (i in 1..25) {
            val boton = Button(this)
            boton.textSize = 16f
            boton.setPadding(10, 10, 10, 10)
            boton.layoutParams = GridLayout.LayoutParams().apply {
                width = 150
                height = 150
            }

            boton.id = i // Asigna un id único (b1, b2…)
            boton.setOnClickListener {
                val numero = boton.text.toString()
                if (numero.isNotEmpty()) {
                    Toast.makeText(this, "Número: $numero", Toast.LENGTH_SHORT).show()
                }
            }

            botones.add(boton)
            matrizBotones.addView(boton)
        }
    }

    private fun asignarNumerosRandom() {
        for (boton in botones) {
            val randomNum = Random.nextInt(1, 101) // del 1 al 100
            boton.text = randomNum.toString()
        }
    }

    private fun limpiarMatriz() {
        for (boton in botones) {
            boton.text = ""
        }
    }
}
