package com.example.formulariovalidado


import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nombre = findViewById<EditText>(R.id.etNombre)
        val apellidoPaterno = findViewById<EditText>(R.id.etApellidoPaterno)
        val apellidoMaterno = findViewById<EditText>(R.id.etApellidoMaterno)
        val edad = findViewById<EditText>(R.id.etEdad)
        val calle = findViewById<EditText>(R.id.etCalle)
        val celular = findViewById<EditText>(R.id.etCelular)
        val numeroControl = findViewById<EditText>(R.id.etNumeroControl)
        val spinnerCarrera = findViewById<Spinner>(R.id.spCarrera)
        val botonEnviar = findViewById<Button>(R.id.btnEnviar)
        val botonLimpiar = findViewById<Button>(R.id.btnLimpiar)

        val carreras = arrayOf(
            "Selecciona una carrera",
            "Ingeniería en TICs",
            "Ingeniería en Sistemas",
            "Ingeniería Industrial"
        )

        val adaptador = ArrayAdapter(this, android.R.layout.simple_spinner_item, carreras)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCarrera.adapter = adaptador

        botonEnviar.setOnClickListener {
            val n = nombre.text.toString().trim()
            val ap = apellidoPaterno.text.toString().trim()
            val am = apellidoMaterno.text.toString().trim()
            val e = edad.text.toString().trim()
            val c = calle.text.toString().trim()
            val cel = celular.text.toString().trim()
            val nc = numeroControl.text.toString().trim()
            val car = spinnerCarrera.selectedItem.toString()

            if (n.isEmpty() || ap.isEmpty() || am.isEmpty() || e.isEmpty() ||
                c.isEmpty() || cel.isEmpty() || nc.isEmpty() || car == "Selecciona una carrera") {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val mensaje = """
                    Datos ingresados:
                    $n $ap $am
                    Edad: $e
                    Calle: $c
                    Celular: $cel
                    Carrera: $car
                    No. Control: $nc
                """.trimIndent()
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
            }
        }

        botonLimpiar.setOnClickListener {
            nombre.text.clear()
            apellidoPaterno.text.clear()
            apellidoMaterno.text.clear()
            edad.text.clear()
            calle.text.clear()
            celular.text.clear()
            numeroControl.text.clear()
            spinnerCarrera.setSelection(0)
            Toast.makeText(this, "Formulario limpiado", Toast.LENGTH_SHORT).show()
        }
    }
}

