package com.example.ventanas


import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a los campos
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etApellidoPaterno = findViewById<EditText>(R.id.etApellidoPaterno)
        val etApellidoMaterno = findViewById<EditText>(R.id.etApellidoMaterno)
        val etEdad = findViewById<EditText>(R.id.etEdad)
        val etCalle = findViewById<EditText>(R.id.etCalle)
        val etCelular = findViewById<EditText>(R.id.etCelular)
        val etNumControl = findViewById<EditText>(R.id.etNumControl)
        val spCarrera = findViewById<Spinner>(R.id.spCarrera)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)
        val btnLimpiar = findViewById<Button>(R.id.btnLimpiar)

        // Opciones para el Spinner
        val carreras = arrayOf("Ingeniería en TICs", "Ingeniería en Sistemas", "Ingeniería Industrial")
        val adaptador = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, carreras)
        spCarrera.adapter = adaptador

        // Botón Enviar
        btnEnviar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val apPaterno = etApellidoPaterno.text.toString().trim()
            val apMaterno = etApellidoMaterno.text.toString().trim()
            val edad = etEdad.text.toString().trim()
            val calle = etCalle.text.toString().trim()
            val celular = etCelular.text.toString().trim()
            val numControl = etNumControl.text.toString().trim()
            val carrera = spCarrera.selectedItem.toString()

            // Validación simple
            if (nombre.isEmpty() || apPaterno.isEmpty() || apMaterno.isEmpty() || edad.isEmpty() ||
                calle.isEmpty() || celular.isEmpty() || numControl.isEmpty()) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Mostrar ventana con todos los datos
            val mensaje = """
                Nombre completo: $nombre $apPaterno $apMaterno
                Edad: $edad
                Calle: $calle
                Celular: $celular
                Carrera: $carrera
                Número de Control: $numControl
            """.trimIndent()

            AlertDialog.Builder(this)
                .setTitle("Información del Formulario")
                .setMessage(mensaje)
                .setPositiveButton("Aceptar", null)
                .show()

            Toast.makeText(this, "Formulario enviado correctamente", Toast.LENGTH_SHORT).show()
        }

        // Botón Limpiar
        btnLimpiar.setOnClickListener {
            etNombre.text.clear()
            etApellidoPaterno.text.clear()
            etApellidoMaterno.text.clear()
            etEdad.text.clear()
            etCalle.text.clear()
            etCelular.text.clear()
            etNumControl.text.clear()
            spCarrera.setSelection(0)
            Toast.makeText(this, "Formulario limpiado", Toast.LENGTH_SHORT).show()
        }
    }
}
