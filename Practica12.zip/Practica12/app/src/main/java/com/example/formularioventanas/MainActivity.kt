package com.example.formularioventanas


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    private lateinit var etLogin: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnOk: Button
    private lateinit var btnRegistrar: Button
    private lateinit var btnNoRecuerdo: Button
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etLogin = findViewById(R.id.etLogin)
        etPassword = findViewById(R.id.etPassword)
        btnOk = findViewById(R.id.btnOk)
        btnRegistrar = findViewById(R.id.btnRegistrar)
        btnNoRecuerdo = findViewById(R.id.btnNoRecuerdo)

        prefs = getSharedPreferences("Usuarios", MODE_PRIVATE)

        btnRegistrar.setOnClickListener {
            startActivity(Intent(this, RegistroActivity::class.java))
        }

        btnNoRecuerdo.setOnClickListener {
            startActivity(Intent(this, RecuperarActivity::class.java))
        }

        btnOk.setOnClickListener {
            val login = etLogin.text.toString()
            val password = etPassword.text.toString()

            val storedLogin = prefs.getString("login", "")
            val storedPass = prefs.getString("password", "")

            if (login.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
            } else if (login == storedLogin && password == storedPass) {
                val intent = Intent(this, BienvenidaActivity::class.java)
                intent.putExtra("login", login)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Datos incorrectos o usuario no registrado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

