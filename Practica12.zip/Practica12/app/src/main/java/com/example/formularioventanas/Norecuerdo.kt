package com.example.formularioventanas


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class RecuperarActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_norecuerdo)

        val etLoginRecuperar: EditText = findViewById(R.id.etLoginRecuperar)
        val etClaveRecuperar: EditText = findViewById(R.id.etClaveRecuperar)
        val btnOkRecuperar: Button = findViewById(R.id.btnOkRecuperar)

        prefs = getSharedPreferences("Usuarios", MODE_PRIVATE)

        btnOkRecuperar.setOnClickListener {
            val login = etLoginRecuperar.text.toString()
            val clave = etClaveRecuperar.text.toString()

            val storedLogin = prefs.getString("login", "")
            val storedClave = prefs.getString("clave", "")

            if (login.isEmpty() || clave.isEmpty()) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
            } else if (login == storedLogin && clave == storedClave) {
                val intent = Intent(this, BienvenidaActivity::class.java)
                intent.putExtra("login", login)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

