package com.example.formularioventanas


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class RegistroActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_altas)

        val etNumeroControl: EditText = findViewById(R.id.etNumeroControl)
        val etNombre: EditText = findViewById(R.id.etNombre)
        val etClave: EditText = findViewById(R.id.etClave)
        val etLogin: EditText = findViewById(R.id.etLogin)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val etCorreo: EditText = findViewById(R.id.etCorreo)
        val etTelefono: EditText = findViewById(R.id.etTelefono)
        val btnAltas: Button = findViewById(R.id.btnAltas)

        prefs = getSharedPreferences("Usuarios", MODE_PRIVATE)

        btnAltas.setOnClickListener {
            if (etNumeroControl.text.isEmpty() || etNombre.text.isEmpty() || etClave.text.isEmpty()
                || etLogin.text.isEmpty() || etPassword.text.isEmpty()
                || etCorreo.text.isEmpty() || etTelefono.text.isEmpty()
            ) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val editor = prefs.edit()
                editor.putString("numeroControl", etNumeroControl.text.toString())
                editor.putString("nombre", etNombre.text.toString())
                editor.putString("clave", etClave.text.toString())
                editor.putString("login", etLogin.text.toString())
                editor.putString("password", etPassword.text.toString())
                editor.putString("correo", etCorreo.text.toString())
                editor.putString("telefono", etTelefono.text.toString())
                editor.apply()

                Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}

