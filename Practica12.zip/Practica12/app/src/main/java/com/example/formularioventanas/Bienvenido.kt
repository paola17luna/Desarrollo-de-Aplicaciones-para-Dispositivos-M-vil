package com.example.formularioventanas


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class BienvenidaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bienvenido)

        val tvBienvenida: TextView = findViewById(R.id.tvBienvenida)
        val login = intent.getStringExtra("login")

        tvBienvenida.text = "¡Bienvenid@ $login!"
    }
}

