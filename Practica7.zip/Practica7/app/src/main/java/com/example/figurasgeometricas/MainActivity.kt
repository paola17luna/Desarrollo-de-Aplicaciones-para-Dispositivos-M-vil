package com.example.figurasgeometricas

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.PI
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    private lateinit var rgFiguras: RadioGroup
    private lateinit var contenedorDatos: LinearLayout
    private lateinit var btnCalcular: Button
    private lateinit var tvResultado: TextView

    // Campos dinámicos
    private val campos = mutableListOf<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rgFiguras = findViewById(R.id.rgFiguras)
        contenedorDatos = findViewById(R.id.contenedorDatos)
        btnCalcular = findViewById(R.id.btnCalcular)
        tvResultado = findViewById(R.id.tvResultado)

        // Detectar cambio de figura
        rgFiguras.setOnCheckedChangeListener { _, checkedId ->
            mostrarCampos(checkedId)
        }

        // Calcular área al presionar el botón
        btnCalcular.setOnClickListener {
            calcularArea()
        }
    }

    private fun mostrarCampos(checkedId: Int) {
        contenedorDatos.removeAllViews()
        campos.clear()

        when (checkedId) {
            R.id.rbTriangulo -> {
                crearCampo("Base")
                crearCampo("Altura")
            }
            R.id.rbCirculo -> {
                crearCampo("Radio")
            }
            R.id.rbRectangulo -> {
                crearCampo("Base")
                crearCampo("Altura")
            }
            R.id.rbTrapecio -> {
                crearCampo("Base mayor")
                crearCampo("Base menor")
                crearCampo("Altura")
            }
        }
    }

    private fun crearCampo(etiqueta: String) {
        val tv = TextView(this)
        tv.text = etiqueta

        val et = EditText(this)
        et.hint = "Ingresa $etiqueta"
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

        contenedorDatos.addView(tv)
        contenedorDatos.addView(et)
        campos.add(et)
    }

    private fun calcularArea() {
        val checkedId = rgFiguras.checkedRadioButtonId

        try {
            val area = when (checkedId) {
                R.id.rbTriangulo -> {
                    val base = campos[0].text.toString().toDouble()
                    val altura = campos[1].text.toString().toDouble()
                    (base * altura) / 2
                }
                R.id.rbCirculo -> {
                    val radio = campos[0].text.toString().toDouble()
                    PI * radio.pow(2)
                }
                R.id.rbRectangulo -> {
                    val base = campos[0].text.toString().toDouble()
                    val altura = campos[1].text.toString().toDouble()
                    base * altura
                }
                R.id.rbTrapecio -> {
                    val baseMayor = campos[0].text.toString().toDouble()
                    val baseMenor = campos[1].text.toString().toDouble()
                    val altura = campos[2].text.toString().toDouble()
                    ((baseMayor + baseMenor) * altura) / 2
                }
                else -> {
                    Toast.makeText(this, "Selecciona una figura", Toast.LENGTH_SHORT).show()
                    return
                }
            }

            tvResultado.text = "Área: %.2f".format(area)
        } catch (e: Exception) {
            Toast.makeText(this, "Completa todos los campos correctamente", Toast.LENGTH_SHORT).show()
        }
    }
}
