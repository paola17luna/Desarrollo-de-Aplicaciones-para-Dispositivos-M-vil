package com.example.saludosvalidado


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a los elementos del layout
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val btnSaludar = findViewById<Button>(R.id.btnSaludar)

        // Evento al presionar el botón
        btnSaludar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()

            if (nombre.isEmpty()) {
                // Si el campo está vacío, muestra un mensaje de error
                Toast.makeText(this, "Error: Por favor escribe tu nombre", Toast.LENGTH_SHORT).show()
            } else {
                // Si tiene texto, muestra el saludo
                Toast.makeText(this, "Hola $nombre, bienvenido ¿cómo estás?", Toast.LENGTH_LONG).show()
            }
        }
    }
}
