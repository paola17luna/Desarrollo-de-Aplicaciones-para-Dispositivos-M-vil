package com.example.menuv


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a los botones del XML
        val button1 = findViewById<Button>(R.id.button)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)
        val button5 = findViewById<Button>(R.id.button5)
        val button6 = findViewById<Button>(R.id.button6)
        val button7 = findViewById<Button>(R.id.button7)
        val button8 = findViewById<Button>(R.id.button8)

        // Asignación de acciones a cada botón
        button1.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 1", Toast.LENGTH_SHORT).show()
        }

        button2.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 2", Toast.LENGTH_SHORT).show()
        }

        button3.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 3", Toast.LENGTH_SHORT).show()
        }

        button4.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 4", Toast.LENGTH_SHORT).show()
        }

        button5.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 7", Toast.LENGTH_SHORT).show()
        }

        button6.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 8", Toast.LENGTH_SHORT).show()
        }

        button7.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 10", Toast.LENGTH_SHORT).show()
        }

        button8.setOnClickListener {
            Toast.makeText(this, "Bienvenido a la Práctica 12", Toast.LENGTH_SHORT).show()
        }
    }
}
